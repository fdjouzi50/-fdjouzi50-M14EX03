 package dz.etm.formation.model;

import java.util.Objects;

/**
 * Représente un point dans un <b>axe orthogonal</b>
 */
//1. création de la classe en indiquant le package
public class Point extends Object {

    
}
