package dz.etm.formation.model;

public class Cube extends Carre {

    
}
