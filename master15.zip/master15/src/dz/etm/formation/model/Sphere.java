package dz.etm.formation.model;

public class Sphere extends Cercle{

    
}
