package dz.etm.formation.model;

public abstract class FormeGeometrique {

    
}
