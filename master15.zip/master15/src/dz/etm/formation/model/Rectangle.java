package dz.etm.formation.model;

public class Rectangle extends Carre {

    
}
