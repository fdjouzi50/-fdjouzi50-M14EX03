package dz.etm.formation.model;

public class Cercle extends FormeGeometrique {

    
}
