package dz.etm.formation.model;

public class Carre extends FormeGeometrique {

    
}
